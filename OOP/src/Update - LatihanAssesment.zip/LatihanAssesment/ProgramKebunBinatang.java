package LatihanAssesment;

public class ProgramKebunBinatang {
    public static void lakukanInteraksi(Hewan hewan){
        hewan.bersuara();
    }
}
