package LatihanAssesment;
// import java.util.Scanner;
public class Project {
    public static void main(String[] args) {
        Hewan Mamalia = new Mamalia();
        Hewan Burung = new Burung();
        ProgramKebunBinatang.lakukanInteraksi(Mamalia);
        ProgramKebunBinatang.lakukanInteraksi(Burung);
    }
}
