package SoalTipeA;

interface Flyable {
    public void fly();
}
