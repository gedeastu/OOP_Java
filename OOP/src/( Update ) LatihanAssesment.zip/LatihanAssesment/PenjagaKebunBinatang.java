package LatihanAssesment;

public class PenjagaKebunBinatang {
    String namaPenjaga;
    int jumlahTugasHarian;

    void lakukanTugas(){
        System.out.println("Penjaga kebun binatang sedang melakukan tugas");
    }
}
