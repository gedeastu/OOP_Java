package LatihanAssesment;

public class Project {
    public static void main(String[] args) {
        Hewan hewan = new Mamalia();
        ProgramKebunBinatang.lakukanInteraksi(hewan);
    }
}
