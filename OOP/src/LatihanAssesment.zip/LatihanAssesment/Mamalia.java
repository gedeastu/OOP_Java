package LatihanAssesment;

class Mamalia extends Hewan {
    String jenisMamalia;

    @Override
    public void bersuara(){
        System.out.println("Suara Mamalia");
    }
}
